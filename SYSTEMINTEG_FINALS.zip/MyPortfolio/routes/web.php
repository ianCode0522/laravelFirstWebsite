<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PortfolioController;


Route::get("/", function () {
    return view('portfolio.index');
})->name('home');

Route::post('home', [PortfolioController::class, 'sendEmail'])->name('sendEmail');