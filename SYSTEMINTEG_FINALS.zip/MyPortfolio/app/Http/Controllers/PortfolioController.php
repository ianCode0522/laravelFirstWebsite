<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;

class PortfolioController extends Controller
{
    public function sendEmail(Request $request)
    {
        $validateData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'phone' => 'required|numeric|digits_between:7,15', 
            'message' => 'required|string',
            'attachment' => 'nullable|file|max:5120|mimes:jpg,jpeg,png,pdf,doc,docx', 
        ]);

        try {
            Mail::send([], [], function ($message) use ($validateData, $request) {
                $message->to('gianxavier.aquino@dwcc.edu.ph')
                    ->subject('Portfolio Contact Form Submission')
                    ->setBody(
                        '<strong>Name:</strong> ' . $validateData['name'] . '<br>' .
                        '<strong>Email:</strong> ' . $validateData['email'] . '<br>' .
                        '<strong>Number:</strong> ' . $validateData['phone'] . '<br>' .
                        '<strong>Message:</strong><br>' . nl2br($validateData['message']),
                        'text/html'
                    );

                if ($request->hasFile('attachment')) {
                    $file = $request->file('attachment');
                    $message->attach($file->getRealPath(), [
                        'as' => $file->getClientOriginalName(),
                        'mime' => $file->getMimeType(),
                    ]);
                }
            });

            return back()->with('success', 'Email sent successfully with attachment!');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to send email. Please try again later.');
        }
    }
}
