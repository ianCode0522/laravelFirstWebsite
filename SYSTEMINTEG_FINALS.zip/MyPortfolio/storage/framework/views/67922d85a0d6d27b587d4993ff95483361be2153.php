<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gian's Portfolio</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    <!-- Boxicons -->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <link rel="stylesheet" href="/css/index.css">
  
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <span class="navbar-brand m-custom">Gian's Portfolio</span>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon ms-4">☰</span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">About Me</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#background">Background</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#project">Projects</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#contact">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="content" style="margin-top: 100px">
        <section id="about" class="container py-5 d-flex justify-content-center align-items-center about-custom">
            <div class="about-blur-background"></div>
            <div class="container-lg">
                <div class="about-content-wrapper">
                    <div class="row justify-content-center align-items-center about-content-custom">
                        <div class="col-md-6">
                            <div class="home-text about-text-custom">
                                <p class="mb-0">Hello I'm</p>
                                <p class="mb-0 h-custom">Gian Xavier</p>
                                <p>A Persistent Coder Who Relentlessly Explores <br>
                                and Masters New Programs!</p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="home-img">
                                <img src="assets/me.jpg" alt="me" class="me-custom">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="background" class="container-bg py-5 mt-3">
            <div class="container background_container">
                <div class="background_left">
                    <h1>Background</h1>
                    <p>
                    Gained knowledge and skills through up-to-date programs and courses, ensuring a strong foundation in current industry practices.
                    </p>
                </div>
                <div class="background-content col-lg-8">
                    <div class="row">
                        <div class="col-md-4 col-sm=12 mb-3 ms-0 mt-4">
                            <article class="background hover-animate">
                                <h5> <span class="background_icon"><i class='bx bxl-adobe'></i>Graphic Design</span></h5>
                                <div class="details">
                                    <p>Experienced in creating visually compelling designs using Adobe Creative Suite</p>
                                </div>
                            </article>
                        </div>
                        <div class="col-md-4 col-sm=12 mb-3 ms-0 mt-4">
                            <article class="background hover-animate">
                                <h5> <span class="background_icon"><i class='bx bxs-user' style='color:rgba(245,210,32,0.95)' ></i>UI/UX</span></h5>
                                <div class="details">
                                    <p>Expertise in designing intuitive interfaces and enhancing user experiences through research and prototyping.</p>
                                </div>
                            </article>
                        </div>
                        <div class="col-md-4 col-sm=12 mb-3 ms-0 mt-4">
                            <article class="background hover-animate">
                                <h5> <span class="background_icon"><i class='bx bx-data' style='color:rgba(115,185,254,0.95)'></i>SQL Database</span></h5>
                                <div class="details">
                                    <p>Proficient in designing, managing, and querying relational databases for efficient data storage and retrieval</p>
                                </div>
                            </article>
                        </div>
                    </div>
                    <div class="row">
                    <div class="col-md-4 col-sm=12 mb-3 ms-0 mt-0">
                            <article class="background hover-animate">
                                <h5> <span class="background_icon"><i class='bx bx-search-alt' style='color:#8fff2c'  ></i>Data Analyst</span></h5>
                                <div class="details">
                                    <p>Experienced in data analysis, visualization, and delivering insights using Excel, SQL, and Python.</p>
                                </div>
                            </article>
                        </div>
                        <div class="col-md-4 col-sm=12 mb-3 ms-0 mt-0">
                            <article class="background hover-animate">
                                <h5> <span class="background_icon"><i class='bx bx-station' style='color:rgba(255,82,215,0.95)'  ></i>Networking</span></h5>
                                <div class="details">
                                    <p>Skilled in configuring and managing networks for optimal performance and security.</p>
                                </div>
                            </article>
                        </div>
                        <div class="col-md-4 col-sm=12 mb-3 ms-0 mt-0">
                            <article class="background hover-animate">
                                <h5 class="fs-10px"> <span class="background_icon"><i class='bx bx-cloud-upload' style='color:#000d70'  ></i>Cloud</span></h5>
                                <div class="details">
                                    <p>Proficient in deploying and optimizing cloud solutions on AWS, Azure, or Google Cloud.</p>
                                </div>
                            </article>
                        </div>
                    </div>
                </div>
            </div>
        </section>

                <section id="project" class="container py-5">
                    <div class="project_container">
                        <h1>Projects</h1>
                        <p>
                            Explore my sample projects!
                        </p>
                    </div>
                    <div class="row">
                        <div id="pictureShuffle1" class="carousel slide col" data-bs-ride="carousel" data-bs-interval="3000">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="assets/ss1.png" class="w-100" alt="Project 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="assets/ss2.png" class="w-100" alt="Project 2">
                                </div>
                                <div class="carousel-item">
                                    <img src="assets/ss3.png" class="w-100" alt="Project 3">
                                </div>
                                <div class="carousel-item">
                                    <img src="assets/ss4.png" class="w-100" alt="Project 4">
                                </div>
                                <div class="carousel-item">
                                    <img src="assets/ss5.png" class="w-100" alt="Project 5">
                                </div>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#pictureShuffle1" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#pictureShuffle1" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            </button>
                        </div>
                    </div>
                </section>
                <section id="awards" class="container py-5">
                    <div class="resume-section-content">
                        <div class="text-center mb-5">
                            <h2 class="fw-bold">Certifications</h2>
                            <p class="lead text-muted">Certificates that validate my skills and achievements</p>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="certificate-card">
                                    <img src="assets/ct2.jpg" alt="Certificate 1" class="img-fluid rounded shadow-sm">
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="certificate-card">
                                    <img src="assets/ct1.jpg" alt="Certificate 2" class="img-fluid rounded shadow-sm">
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="certificate-card">
                                    <img src="assets/ct3.jpg" alt="Certificate 3" class="img-fluid rounded shadow-sm">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="certificate-card">
                                    <img src="assets/ct4.jpg" alt="Certificate 4" class="img-fluid rounded shadow-sm">
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="certificate-card">
                                    <img src="assets/ct5.jpg" alt="Certificate 5" class="img-fluid rounded shadow-sm">
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="certificate-card">
                                    <img src="assets/ct6.jpg" alt="Certificate 6" class="img-fluid rounded shadow-sm">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
        <div id="contact"></div>
            <section class="container py-5 section-contact-custom">
                <h1>Contact Me ;></h1>
                <p>An individual persistent of learning!</p>
                <div class="email-container container-fluid px-0">
                    <div class="contact-container py-0">
                        <div class="row justify-content-center align-items-center vh-custom">
                            <div class="col-lg-6 mb-3">
                                <div class="card form-container no-border">
                                    <div class="card-body p-4">
                                        <form id="contactForm" action="<?php echo e(route('sendEmail')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="mb-2">
                                                <label for="name" class="form-label">Your Name:</label>
                                                <input type="text" id="name" name="name" class="form-control" placeholder="Enter your name" required>
                                            </div>
                                            <div class="row mb-2">
                                                <div class="col-lg-6">
                                                    <label for="email" class="form-label">Your Email:</label>
                                                    <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>    
                                                </div>
                                                <div class="col-lg-6">
                                                    <label for="name" class="form-label">Your Contact Number:</label>
                                                    <input type="text" id="phone" name="phone" class="form-control" placeholder="Enter your phone number" required>
                                                </div>
                                            </div>
                                            <div class="mb-2">
                                                <label for="message" class="form-label">Your Message:</label>
                                                <textarea id="message" name="message" rows="5" class="form-control" placeholder="Write your message here" required></textarea>
                                            </div>
                                            <div class="mb-2">
                                                <label for="attachment" class="form-label">Attach File:</label>
                                                <input type="file" id="attachment" name="attachment" class="form-control">
                                            </div>
                                            <button type="submit" class="btn btn-custom w-100 py-1">Send Email</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="contact-info text-center text-lg-start">
                                    <h5>Contact Me!</h5>
                                    <p>Please reach out through the following:</p>
                                    <p class="mb-0"><strong>Email:</strong> gianxavier.aquino@dwcc.edu.ph</p>
                                    <p class="mb-0"><strong>Phone:</strong>+63 929 8490 815</p>
                                    <p class="mb-0"><strong>Address: </strong>Ibaba West, Calapan City, Oriental Mindoro</p>

                                    <br>
                                    <div class="icon_container">
                                    <a href="https://www.linkedin.com/in/gian-xavier-aquino-0867aa273/"> <i class='bx bxl-linkedin' style='color:#1b6db8'  ></i></a>
                                        <a href="https://www.facebook.com/gianxavier.aquino/"><i class='bx bxl-facebook-square'></i></a>
                                        <a href="https://github.com/ianCode0522"><i class='bx bxl-github' style='color:#3c4b59' ></i></a>
                                    </div>
                                </div>
                            </div>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
        </div>

    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- <script>
            document.getElementById("downloadCvButton").addEventListener("click", function() {
                
                const cvFile = 'assets/CV_Gian.pdf';  
                const link = document.createElement('a');
                link.href = cvFile;
                link.download = 'Gian_Xavier_CV.pdf';  
                document.body.appendChild(link);

                link.click();

                document.body.removeChild(link);
            });
        </script>

        <button id="downloadCvButton" class="btn btn-custom w-100 py-1 mt-3">
            My C/V
        </button> -->

</body>
</html>
<?php /**PATH C:\laragon\www\MyPortfolio\resources\views/portfolio/index.blade.php ENDPATH**/ ?>