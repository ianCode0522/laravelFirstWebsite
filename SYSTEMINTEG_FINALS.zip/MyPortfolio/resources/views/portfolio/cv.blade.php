<script>
    document.getElementById("downloadCvButton").addEventListener("click", function() {
        // The file path for your CV (make sure the file is in the correct directory)
        const cvFile = 'assets/CV_Gian.pdf';  // Modify the path as needed
        
        // Create a temporary anchor element to trigger the download
        const link = document.createElement('a');
        link.href = cvFile;
        link.download = 'Gian_Xavier_CV.pdf';  // The name the file will have when downloaded
        document.body.appendChild(link);
        
        // Trigger the click event to start the download
        link.click();
        
        // Clean up by removing the temporary link element
        document.body.removeChild(link);
    });
</script>

<button id="downloadCvButton" class="btn btn-custom w-100 py-1 mt-3">
    Download My CV
</button>